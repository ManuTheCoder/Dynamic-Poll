<?php 
include("cred.php");
try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $stmt = $conn->prepare("SELECT * FROM `options` where `parent`=".$_GET['id']. " ORDER by votes DESC");
  $stmt->execute();

  // set the resulting array to associative
  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
  $total = 0;
  $s = $stmt->fetchAll();
  foreach($s as $row1) {$total += ($row1['votes']);}
  foreach($s as $row) {
    //   echo '{"name": '.json_encode($row['name']).'},';
    
    $percent = ($row['votes']/$total)*100;
?>

<div class="card voteOption" style="width: 100%">
	<div class="card-content">
		<span style="vertical-align: middle"><?=strval($row['name']);?></span>
		<span class="right green-text" style="vertical-align: middle">
			<b><?=strval(round($percent));?>%</b> | <?=strval($row['votes']);?>
		</span>
	</div>
	<div id="progress" class="progress">
		<div class="determinate" style="width:<?=$percent; ?>%"></div>
	</div>
</div>
<?php } 
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
$conn = null;

?>

<style>
.progress {
    background-color: #c8e6c9  ;
}


.progress .determinate {
    background-color: #2e7d32;
}</style>
<script>