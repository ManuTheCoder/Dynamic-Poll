<footer class="page-footer blue" style="padding: 0 !important">
    <div class="footer-copyright">
    <div class="container">
    © Copyright <?=date("Y");?> All rights reserved
    <a class="grey-text text-lighten-4 right" href="https://manuthecoder.ml">A swag app by Manu!</a>
    </div>
    </div>
</footer>