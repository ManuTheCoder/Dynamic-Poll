<?php
$servername = "localhost";
$dbname = "iqsdntnq_pollapp-ml";
$username = "iqsdntnq";
$password = "y9xVA7BGkngLjAS78zXYdwYFwkwVq5Y8PwdXB82SehhghcUf2e94cY37LZjqyPHV2p9TqNK5KARVDLMxhDGdy44JLHvqb5643bvn8Hyzv4HL2P2DJnk";
?>